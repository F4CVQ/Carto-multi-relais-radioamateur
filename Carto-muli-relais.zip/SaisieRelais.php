<?php

// Mot de passe administrateur hashé avec la fonction password_hash de PHP - A changer !
define('ADMIN_PASSWORD', '$2b$12$opU8kDkCil8legic5VNAputfMtLKyRd/ui.loEcmrOxlZbiG2ob5a'); // Mot de passe : F1zbvRa88Vosges

$json_file = 'data.json';
$relais_file = 'relais.json';
$message = '';
$error = '';

// Nom dynamique du fichier PHP actuel
$current_script = htmlspecialchars($_SERVER['PHP_SELF']);

// Onglet actif
$tab = $_GET['tab'] ?? 'reports';
if (!in_array($tab, ['reports', 'relais', 'stats'])) {
    $tab = 'reports';
}
function tab_url($t, $script) {
    return $script . '?tab=' . $t;
}

// Vérification de l'authentification
session_start();

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset($_SESSION['logged_in']);
    session_destroy();
    header('Location: ' . $current_script);
    exit;
}

if (isset($_POST['password'])) {
    if(password_verify($_POST['password'],ADMIN_PASSWORD)) {
        $_SESSION['logged_in'] = true;
    } else {
        $error = "Mot de passe incorrect.";
    }
}

$is_logged_in = isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;

// --- Fonctions utilitaires ---

function load_json($file) {
    if (file_exists($file)) {
        return json_decode(file_get_contents($file), true) ?? [];
    }
    return [];
}

function save_json($file, $data) {
    return file_put_contents($file, json_encode(array_values($data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Message d'erreur détaillé pour diagnostiquer un échec d'écriture (droits fichier/dossier)
function write_error_detail($file) {
    $dir = dirname(realpath($file) ?: $file) ?: '.';
    if (!file_exists($file)) {
        if (!is_writable($dir)) {
            return "Le fichier <strong>$file</strong> n'existe pas encore et le dossier <strong>" . htmlspecialchars($dir) . "</strong> n'est pas accessible en écriture par PHP (droits requis : 755 minimum sur le dossier).";
        }
        return "Le fichier <strong>$file</strong> n'a pas pu être créé dans <strong>" . htmlspecialchars($dir) . "</strong>. Vérifiez les droits du dossier.";
    }
    if (!is_writable($file)) {
        return "Le fichier <strong>$file</strong> existe mais n'est pas accessible en écriture par PHP. Mettez-le en droits 666 (ou 664) via votre client FTP / gestionnaire de fichiers.";
    }
    return "Erreur inconnue lors de l'écriture de <strong>$file</strong>. Vérifiez les droits du fichier et du dossier.";
}

// Conversion Maidenhead Locator -> [lat, lon]
function locator_to_latlon($loc) {
    $loc = strtoupper(trim($loc));
    if (strlen($loc) < 4) return null;
    $lon = (ord($loc[0]) - 65) * 20 - 180 + (ord($loc[2]) - 48) * 2 + (strlen($loc) >= 6 ? (ord($loc[4]) - 65) * (2/24) + (1/24) : 1);
    $lat = (ord($loc[1]) - 65) * 10 - 90 + (ord($loc[3]) - 48) * 1 + (strlen($loc) >= 6 ? (ord($loc[5]) - 65) * (1/24) + (0.5/24) : 0.5);
    return [$lat, $lon];
}

// Catégorie de report (identique à la logique de la carte)
function get_report_category($report) {
    if (!$report) return 'low';
    $rep = strtoupper(trim($report));
    if (strpos($rep, '59') !== false || strpos($rep, 'S9') !== false || strpos($rep, '+') !== false) return '59';
    if (strpos($rep, '57') !== false || strpos($rep, '58') !== false || strpos($rep, 'S7') !== false || strpos($rep, 'S8') !== false) return '57';
    if (strpos($rep, '55') !== false || strpos($rep, '56') !== false || strpos($rep, 'S5') !== false || strpos($rep, 'S6') !== false) return '55';
    return 'low';
}

// Table approximative des préfectures (centroïdes) des départements métropolitains,
// utilisée pour estimer le département le plus proche à partir des coordonnées du locator.
function departements_france() {
    return [
        ['01','Ain',46.2058,5.2265],['02','Aisne',49.5642,3.6199],['03','Allier',46.5606,3.3325],
        ['04','Alpes-de-Haute-Provence',44.0916,6.2358],['05','Hautes-Alpes',44.5594,6.0793],
        ['06','Alpes-Maritimes',43.7102,7.2620],['07','Ardèche',44.7352,4.6013],['08','Ardennes',49.7723,4.7196],
        ['09','Ariège',42.9648,1.6053],['10','Aube',48.2973,4.0744],['11','Aude',43.2130,2.3491],
        ['12','Aveyron',44.3506,2.5764],['13','Bouches-du-Rhône',43.2965,5.3698],['14','Calvados',49.1829,-0.3707],
        ['15','Cantal',44.9224,2.4448],['16','Charente',45.6484,0.1560],['17','Charente-Maritime',46.1603,-1.1511],
        ['18','Cher',47.0810,2.3988],['19','Corrèze',45.2656,1.7714],['2A','Corse-du-Sud',41.9192,8.7386],
        ['2B','Haute-Corse',42.7028,9.4508],['21',"Côte-d'Or",47.3220,5.0415],["22","Côtes-d'Armor",48.5142,-2.7653],
        ['23','Creuse',46.1701,1.8686],['24','Dordogne',45.1848,0.7218],['25','Doubs',47.2378,6.0241],
        ['26','Drôme',44.9334,4.8924],['27','Eure',49.0243,1.1504],['28','Eure-et-Loir',48.4439,1.4894],
        ['29','Finistère',47.9960,-4.0972],['30','Gard',43.8367,4.3601],['31','Haute-Garonne',43.6047,1.4442],
        ['32','Gers',43.6455,0.5860],['33','Gironde',44.8378,-0.5792],['34','Hérault',43.6108,3.8767],
        ['35','Ille-et-Vilaine',48.1173,-1.6778],['36','Indre',46.8107,1.6911],['37','Indre-et-Loire',47.3941,0.6848],
        ['38','Isère',45.1885,5.7245],['39','Jura',46.6739,5.5540],['40','Landes',43.8905,-0.4988],
        ['41','Loir-et-Cher',47.5861,1.3359],['42','Loire',45.4397,4.3872],['43','Haute-Loire',45.0430,3.8850],
        ['44','Loire-Atlantique',47.2184,-1.5536],['45','Loiret',47.9029,1.9093],['46','Lot',44.4478,1.4351],
        ['47','Lot-et-Garonne',44.2019,0.6212],['48','Lozère',44.5183,3.5005],['49','Maine-et-Loire',47.4784,-0.5632],
        ['50','Manche',49.1147,-1.0900],['51','Marne',48.9578,4.3675],['52','Haute-Marne',48.1113,5.1394],
        ['53','Mayenne',48.0698,-0.7714],['54','Meurthe-et-Moselle',48.6921,6.1844],['55','Meuse',48.7706,5.1611],
        ['56','Morbihan',47.6582,-2.7603],['57','Moselle',49.1193,6.1757],['58','Nièvre',46.9896,3.1591],
        ['59','Nord',50.6292,3.0573],['60','Oise',49.4295,2.0807],['61','Orne',48.4310,0.0931],
        ['62','Pas-de-Calais',50.2910,2.7773],['63','Puy-de-Dôme',45.7772,3.0870],['64','Pyrénées-Atlantiques',43.2951,-0.3708],
        ['65','Hautes-Pyrénées',43.2328,0.0786],['66','Pyrénées-Orientales',42.6886,2.8948],['67','Bas-Rhin',48.5734,7.7521],
        ['68','Haut-Rhin',48.0794,7.3585],['69','Rhône',45.7640,4.8357],['70','Haute-Saône',47.6234,6.1546],
        ['71','Saône-et-Loire',46.3069,4.8283],['72','Sarthe',48.0061,0.1996],['73','Savoie',45.5646,5.9178],
        ['74','Haute-Savoie',45.8992,6.1294],['75','Paris',48.8566,2.3522],['76','Seine-Maritime',49.4431,1.0993],
        ['77','Seine-et-Marne',48.5388,2.6598],['78','Yvelines',48.8014,2.1301],['79','Deux-Sèvres',46.3239,-0.4590],
        ['80','Somme',49.8942,2.2957],['81','Tarn',43.9298,2.1480],['82','Tarn-et-Garonne',44.0181,1.3548],
        ['83','Var',43.1242,5.9280],['84','Vaucluse',43.9493,4.8055],['85','Vendée',46.6705,-1.4267],
        ['86','Vienne',46.5802,0.3404],['87','Haute-Vienne',45.8336,1.2611],['88','Vosges',48.1734,6.4500],
        ['89','Yonne',47.7982,3.5734],['90','Territoire de Belfort',47.6379,6.8629],['91','Essonne',48.6329,2.4291],
        ['92','Hauts-de-Seine',48.8924,2.2072],['93','Seine-Saint-Denis',48.9091,2.4392],['94','Val-de-Marne',48.7904,2.4556],
        ['95',"Val-d'Oise",49.0364,2.0765],
    ];
}

// Estime le département le plus proche à partir d'un locator (distance au carré aux préfectures)
function departement_from_locator($locator) {
    $coords = locator_to_latlon($locator);
    if (!$coords) return null;
    [$lat, $lon] = $coords;
    $best = null;
    $bestDist = null;
    foreach (departements_france() as $d) {
        [$code, $nom, $dlat, $dlon] = $d;
        $dist = pow($lat - $dlat, 2) + pow($lon - $dlon, 2);
        if ($bestDist === null || $dist < $bestDist) {
            $bestDist = $dist;
            $best = "$code - $nom";
        }
    }
    return $best;
}

// Suppression d'une entrée de report
if ($is_logged_in && isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $current_data = load_json($json_file);
    $current_data = array_filter($current_data, function($item) use ($delete_id) {
        return ($item['id'] ?? '') !== $delete_id;
    });
    save_json($json_file, $current_data);
    $message = "Entrée supprimée avec succès.";
    $tab = 'reports';
}

// Suppression d'un relais
if ($is_logged_in && isset($_GET['delete_relais'])) {
    $delete_id = $_GET['delete_relais'];
    $current_relais = load_json($relais_file);
    $current_relais = array_filter($current_relais, function($item) use ($delete_id) {
        return ($item['id'] ?? '') !== $delete_id;
    });
    save_json($relais_file, $current_relais);
    $message = "Relais supprimé avec succès.";
    $tab = 'relais';
}

// Traitement du formulaire Report (Ajout OU Modification)
if ($is_logged_in && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'report') {
    $indicatif = strtoupper(trim($_POST['indicatif'] ?? ''));
    $locator = strtoupper(trim($_POST['locator'] ?? ''));
    $report = trim($_POST['report'] ?? '');
    $materiel = trim($_POST['materiel'] ?? '');
    $relais_id = trim($_POST['relais_id'] ?? '');
    $edit_id = $_POST['edit_id'] ?? '';

    // La fréquence affichée est celle du relais sélectionné (ou saisie libre en secours)
    $frequence = trim($_POST['frequence'] ?? '');

    if (!empty($indicatif) && !empty($locator)) {
        $current_data = load_json($json_file);

        if (!empty($edit_id)) {
            $updated = false;
            foreach ($current_data as &$item) {
                if (($item['id'] ?? '') === $edit_id) {
                    $item['indicatif'] = $indicatif;
                    $item['locator'] = $locator;
                    $item['report'] = $report;
                    $item['materiel'] = $materiel;
                    $item['frequence'] = $frequence;
                    $item['relais_id'] = $relais_id;
                    $updated = true;
                    break;
                }
            }
            unset($item);
            if ($updated) {
                $message = "Le rapport pour <strong>$indicatif</strong> a bien été mis à jour !";
            }
        } else {
            $new_entry = [
                'id' => uniqid(),
                'indicatif' => $indicatif,
                'locator' => $locator,
                'report' => $report,
                'materiel' => $materiel,
                'frequence' => $frequence,
                'relais_id' => $relais_id,
                'date' => date('Y-m-d H:i')
            ];
            array_unshift($current_data, $new_entry);
            $message = "Le rapport pour <strong>$indicatif</strong> a bien été enregistré !";
        }

        if (!save_json($json_file, $current_data)) {
            $error = "Erreur lors de l'écriture dans data.json. " . write_error_detail($json_file);
            $message = '';
        }
        $tab = 'reports';
    } else {
        $error = "Veuillez remplir au moins l'indicatif et le Maidenhead Locator.";
        $tab = 'reports';
    }
}

// Traitement du formulaire Relais (Ajout OU Modification)
if ($is_logged_in && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'relais') {
    $nom = trim($_POST['nom'] ?? '');
    $indicatif_r = strtoupper(trim($_POST['indicatif_r'] ?? ''));
    $locator_r = strtoupper(trim($_POST['locator_r'] ?? ''));
    $latitude_r = trim($_POST['latitude_r'] ?? '');
    $longitude_r = trim($_POST['longitude_r'] ?? '');
    $frequence_r = trim($_POST['frequence_r'] ?? '');
    $ctcss_r = trim($_POST['ctcss_r'] ?? '');
    $altitude_r = trim($_POST['altitude_r'] ?? '');
    $qth_r = trim($_POST['qth_r'] ?? '');
    $qrz_r = trim($_POST['qrz_r'] ?? '');
    $webcam_r = trim($_POST['webcam_r'] ?? '');
    $edit_relais_id = $_POST['edit_relais_id'] ?? '';

    if (!empty($nom) && !empty($locator_r)) {
        // Si latitude/longitude non fournies, on les déduit du locator
        if ($latitude_r === '' || $longitude_r === '') {
            $coords = locator_to_latlon($locator_r);
            if ($coords) {
                $latitude_r = $coords[0];
                $longitude_r = $coords[1];
            }
        }

        $current_relais = load_json($relais_file);

        if (!empty($edit_relais_id)) {
            $updated = false;
            foreach ($current_relais as &$item) {
                if (($item['id'] ?? '') === $edit_relais_id) {
                    $item['nom'] = $nom;
                    $item['indicatif'] = $indicatif_r;
                    $item['locator'] = $locator_r;
                    $item['latitude'] = (float)$latitude_r;
                    $item['longitude'] = (float)$longitude_r;
                    $item['frequence'] = $frequence_r;
                    $item['ctcss'] = $ctcss_r;
                    $item['altitude'] = $altitude_r;
                    $item['qth'] = $qth_r;
                    $item['qrz'] = $qrz_r;
                    $item['webcam'] = $webcam_r;
                    $updated = true;
                    break;
                }
            }
            unset($item);
            if ($updated) {
                $message = "Le relais <strong>$nom</strong> a bien été mis à jour !";
            }
        } else {
            $new_relais = [
                'id' => 'rel_' . uniqid(),
                'nom' => $nom,
                'indicatif' => $indicatif_r,
                'locator' => $locator_r,
                'latitude' => (float)$latitude_r,
                'longitude' => (float)$longitude_r,
                'frequence' => $frequence_r,
                'ctcss' => $ctcss_r,
                'altitude' => $altitude_r,
                'qth' => $qth_r,
                'qrz' => $qrz_r,
                'webcam' => $webcam_r
            ];
            $current_relais[] = $new_relais;
            $message = "Le relais <strong>$nom</strong> a bien été ajouté !";
        }

        if (!save_json($relais_file, $current_relais)) {
            $error = "Erreur lors de l'écriture dans relais.json. " . write_error_detail($relais_file);
            $message = '';
        }
        $tab = 'relais';
    } else {
        $error = "Veuillez remplir au moins le nom et le Maidenhead Locator du relais.";
        $tab = 'relais';
    }
}

// Chargement des listes
$entries = load_json($json_file);
$relais_list = load_json($relais_file);
$relais_by_id = [];
foreach ($relais_list as $r) {
    $relais_by_id[$r['id']] = $r;
}

// Vérification du mode édition report (si un id passe en URL)
$edit_entry = null;
if (isset($_GET['edit'])) {
    $edit_id_get = $_GET['edit'];
    foreach ($entries as $item) {
        if (($item['id'] ?? '') === $edit_id_get) {
            $edit_entry = $item;
            break;
        }
    }
}

// Vérification du mode édition relais (si un id passe en URL)
$edit_relais_entry = null;
if (isset($_GET['edit_relais'])) {
    $edit_relais_id_get = $_GET['edit_relais'];
    foreach ($relais_list as $item) {
        if (($item['id'] ?? '') === $edit_relais_id_get) {
            $edit_relais_entry = $item;
            break;
        }
    }
}

// --- Calcul des statistiques ---
$stats_categories = ['59' => 0, '57' => 0, '55' => 0, 'low' => 0];
$stats_departements = [];
$stats_relais_counts = [];
$indicatifs_uniques = [];
$locators_counts = [];

foreach ($entries as $item) {
    $cat = get_report_category($item['report'] ?? '');
    $stats_categories[$cat]++;

    if (!empty($item['locator'])) {
        $dep = departement_from_locator($item['locator']);
        if ($dep) {
            $stats_departements[$dep] = ($stats_departements[$dep] ?? 0) + 1;
        }
        $loc = strtoupper(trim($item['locator']));
        $locators_counts[$loc] = ($locators_counts[$loc] ?? 0) + 1;
    }

    if (!empty($item['indicatif'])) {
        $indicatifs_uniques[strtoupper(trim($item['indicatif']))] = true;
    }

    $rid = $item['relais_id'] ?? '';
    $rnom = $relais_by_id[$rid]['nom'] ?? 'Non attribué';
    $stats_relais_counts[$rnom] = ($stats_relais_counts[$rnom] ?? 0) + 1;
}

$indicatifs_tries = array_keys($indicatifs_uniques);
sort($indicatifs_tries, SORT_STRING);

$locators_tries = $locators_counts;
ksort($locators_tries, SORT_STRING);

arsort($stats_departements);
arsort($stats_relais_counts);

$labels_cat = [
    '59' => '🟢 Excellent (59 / S9+)',
    '57' => '🔵 Bon (57 - 58)',
    '55' => '🟠 Moyen (55 - 56)',
    'low' => '🔴 Faible (< 55)'
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration — Couverture Relais des Vosges</title>
    <style>
        :root {
            --primary: #1e3a8a;
            --primary-hover: #1e40af;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text: #0f172a;
            --border: #e2e8f0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
        }
        .container {
            width: 100%;
            max-width: 950px;
        }
        .card {
            background: var(--card-bg);
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            margin-bottom: 24px;
            border: 1px solid var(--border);
        }
        h1, h2, h3 {
            margin-top: 0;
            color: var(--primary);
        }
        .form-group {
            margin-bottom: 16px;
        }
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 6px;
            font-size: 0.9rem;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 1rem;
            font-family: inherit;
        }
        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.15);
        }
        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .grid-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 16px;
        }
        .btn-group {
            display: flex;
            gap: 10px;
        }
        button {
            background-color: var(--primary);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.2s;
        }
        button:hover {
            background-color: var(--primary-hover);
        }
        .cancel-btn {
            background-color: #64748b;
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            display: inline-block;
            text-align: center;
            box-sizing: border-box;
        }
        .cancel-btn:hover { background-color: #475569; }
        .alert {
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .alert-success { background-color: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert-error { background-color: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .header-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .logout-btn {
            background: #ef4444;
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.85rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 0.9rem;
        }
        th, td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid var(--border);
        }
        th { background-color: #f1f5f9; }
        .action-links { display: flex; gap: 8px; }
        .edit-btn { text-decoration: none; font-size: 1.1rem; }
        .delete-btn { color: #ef4444; text-decoration: none; font-weight: bold; font-size: 1.1rem; }

        /* Onglets */
        .tabs { display: flex; gap: 4px; margin-bottom: 20px; border-bottom: 2px solid var(--border); }
        .tab-link {
            padding: 10px 18px;
            text-decoration: none;
            font-weight: 600;
            color: #64748b;
            border-bottom: 3px solid transparent;
            margin-bottom: -2px;
            font-size: 0.95rem;
        }
        .tab-link.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }
        .tab-link:hover { color: var(--primary); }

        .stat-boxes { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 10px; }
        @media (max-width: 700px) { .stat-boxes { grid-template-columns: 1fr 1fr; } .grid-2, .grid-3 { grid-template-columns: 1fr; } }
        .stat-box { background: #f1f5f9; border-radius: 8px; padding: 14px; text-align: center; }
        .stat-box .num { font-size: 1.8rem; font-weight: 800; color: var(--primary); }
        .stat-box .lbl { font-size: 0.8rem; color: #475569; margin-top: 4px; }

        .chip-list { display: flex; flex-wrap: wrap; gap: 6px; }
        .chip { background: #e0e7ff; color: #3730a3; padding: 4px 10px; border-radius: 20px; font-size: 0.85rem; font-weight: 600; }

        .small-note { font-size: 0.78rem; color: #64748b; margin-top: 6px; }
    </style>
</head>
<body>
<div class="container">

    <?php if (!$is_logged_in): ?>
        <div class="card" style="max-width: 400px; margin: 80px auto;">
            <h1>Connexion Admin</h1>
            <p>Saisissez le mot de passe pour gérer les rapports de réception.</p>

            <?php if ($error): ?>
                <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" action="<?= $current_script ?>">
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password" required autofocus>
                </div>
                <button type="submit">Se connecter</button>
            </form>
        </div>
    <?php else: ?>

        <div class="header-bar">
            <h1>Administration — Couverture Relais</h1>
            <a href="<?= $current_script ?>?action=logout" class="logout-btn">Déconnexion</a>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>

        <div class="tabs">
            <a href="<?= tab_url('reports', $current_script) ?>" class="tab-link <?= $tab === 'reports' ? 'active' : '' ?>">📋 Reports</a>
            <a href="<?= tab_url('relais', $current_script) ?>" class="tab-link <?= $tab === 'relais' ? 'active' : '' ?>">📡 Relais</a>
            <a href="<?= tab_url('stats', $current_script) ?>" class="tab-link <?= $tab === 'stats' ? 'active' : '' ?>">📊 Statistiques</a>
        </div>

        <?php if ($tab === 'reports'): ?>

            <div class="card">
                <h2><?= $edit_entry ? '✏️ Modifier le rapport' : '➕ Nouveau rapport reçu par email' ?></h2>
                <form method="POST" action="<?= $current_script ?>">
                    <input type="hidden" name="form_type" value="report">
                    <input type="hidden" name="edit_id" value="<?= htmlspecialchars($edit_entry['id'] ?? '') ?>">

                    <div class="grid-2">
                        <div class="form-group">
                            <label for="indicatif">Indicatif OM / SWL *</label>
                            <input type="text" id="indicatif" name="indicatif" placeholder="ex: F4ABC ou SWL-Jean" value="<?= htmlspecialchars($edit_entry['indicatif'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="locator">Maidenhead Locator *</label>
                            <input type="text" id="locator" name="locator" placeholder="ex: JN38BC ou JN38" value="<?= htmlspecialchars($edit_entry['locator'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="grid-2">
                        <div class="form-group">
                            <label for="report">Report RST / Signal</label>
                            <?php
                                $report_options = [
                                    '🟢 Excellent (59 / S9+)' => ['59', '59+10dB', '59+20dB', 'S9', 'S9+10dB', 'S9+20dB'],
                                    '🔵 Bon (57 - 58)' => ['58', '57', 'S8', 'S7'],
                                    '🟠 Moyen (55 - 56)' => ['56', '55', 'S6', 'S5'],
                                    '🔴 Faible (< 55)' => ['54', '53', '52', '51', 'S4', 'S3', 'S2', 'S1'],
                                ];
                                $current_report = $edit_entry['report'] ?? '';
                                $all_known_values = array_merge(...array_values($report_options));
                                $is_custom_value = ($current_report !== '' && !in_array($current_report, $all_known_values, true));
                            ?>
                            <select id="report" name="report">
                                <option value="">-- Sélectionner un report --</option>
                                <?php if ($is_custom_value): ?>
                                    <option value="<?= htmlspecialchars($current_report) ?>" selected>Valeur actuelle : <?= htmlspecialchars($current_report) ?></option>
                                <?php endif; ?>
                                <?php foreach ($report_options as $group_label => $values): ?>
                                    <optgroup label="<?= htmlspecialchars($group_label) ?>">
                                        <?php foreach ($values as $val): ?>
                                            <option value="<?= htmlspecialchars($val) ?>" <?= ($current_report === $val) ? 'selected' : '' ?>><?= htmlspecialchars($val) ?></option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="relais_id">Relais concerné *</label>
                            <select id="relais_id" name="relais_id" onchange="updateFrequenceFromRelais()" required>
                                <option value="">-- Choisir un relais --</option>
                                <?php foreach ($relais_list as $r): ?>
                                    <?php
                                        $sel = (($edit_entry['relais_id'] ?? '') === $r['id']) ? 'selected' : '';
                                    ?>
                                    <option value="<?= htmlspecialchars($r['id']) ?>" data-frequence="<?= htmlspecialchars($r['frequence'] ?? '') ?>" <?= $sel ?>>
                                        <?= htmlspecialchars($r['nom']) ?> (<?= htmlspecialchars($r['locator']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (empty($relais_list)): ?>
                                <div class="small-note">Aucun relais défini. Ajoutez d'abord un relais dans l'onglet "📡 Relais".</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="frequence">Bande / Mode / Fréquence</label>
                        <input type="text" id="frequence" name="frequence" placeholder="Sélectionnez un relais pour pré-remplir" value="<?= htmlspecialchars($edit_entry['frequence'] ?? '') ?>">
                        <div class="small-note">Pré-rempli automatiquement depuis le relais choisi ; modifiable si besoin.</div>
                    </div>

                    <div class="form-group">
                        <label for="materiel">Conditions de trafic / Matériel / Antenne</label>
                        <input type="text" id="materiel" name="materiel" placeholder="ex: IC-2730 / Antenne Colinéaire à 10m / 25W" value="<?= htmlspecialchars($edit_entry['materiel'] ?? '') ?>">
                    </div>

                    <div class="btn-group">
                        <button type="submit"><?= $edit_entry ? '💾 Sauvegarder les modifications' : '➕ Enregistrer le rapport' ?></button>
                        <?php if ($edit_entry): ?>
                            <a href="<?= tab_url('reports', $current_script) ?>" class="cancel-btn">Annuler</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Rapports déjà enregistrés (<?= count($entries) ?>)</h2>
                <?php if (empty($entries)): ?>
                    <p>Aucun report dans la base pour le moment.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Indicatif</th>
                                <th>Locator</th>
                                <th>Report</th>
                                <th>Relais</th>
                                <th>Matériel</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($entries as $item): ?>
                                <?php $rnom = $relais_by_id[$item['relais_id'] ?? '']['nom'] ?? '<span style="color:#94a3b8;">Non attribué</span>'; ?>
                                <tr>
                                    <td><small><?= htmlspecialchars($item['date'] ?? '-') ?></small></td>
                                    <td><strong><?= htmlspecialchars($item['indicatif'] ?? '') ?></strong></td>
                                    <td><code><?= htmlspecialchars($item['locator'] ?? '') ?></code></td>
                                    <td><?= htmlspecialchars($item['report'] ?? '') ?></td>
                                    <td><small><?= $rnom ?></small></td>
                                    <td><?= htmlspecialchars($item['materiel'] ?? '') ?></td>
                                    <td>
                                        <div class="action-links">
                                            <a href="<?= $current_script ?>?tab=reports&edit=<?= $item['id'] ?>" class="edit-btn" title="Modifier">✏️</a>
                                            <a href="<?= $current_script ?>?tab=reports&delete=<?= $item['id'] ?>" class="delete-btn" onclick="return confirm('Supprimer ce rapport ?');" title="Supprimer">❌</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

        <?php elseif ($tab === 'relais'): ?>

            <div class="card">
                <h2><?= $edit_relais_entry ? '✏️ Modifier le relais' : '➕ Ajouter un relais' ?></h2>
                <p class="small-note">Vous pouvez ajouter ou modifier autant de relais que nécessaire ; chaque report pourra ensuite être rattaché à l'un d'eux.</p>
                <form method="POST" action="<?= $current_script ?>">
                    <input type="hidden" name="form_type" value="relais">
                    <input type="hidden" name="edit_relais_id" value="<?= htmlspecialchars($edit_relais_entry['id'] ?? '') ?>">

                    <div class="grid-2">
                        <div class="form-group">
                            <label for="nom">Nom du relais *</label>
                            <input type="text" id="nom" name="nom" placeholder='ex: F1ZBV « Lola »' value="<?= htmlspecialchars($edit_relais_entry['nom'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="indicatif_r">Indicatif du relais</label>
                            <input type="text" id="indicatif_r" name="indicatif_r" placeholder="ex: F1ZBV" value="<?= htmlspecialchars($edit_relais_entry['indicatif'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="grid-2">
                        <div class="form-group">
                            <label for="locator_r">Maidenhead Locator *</label>
                            <input type="text" id="locator_r" name="locator_r" placeholder="ex: JN38MB" value="<?= htmlspecialchars($edit_relais_entry['locator'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="qth_r">QTH</label>
                            <input type="text" id="qth_r" name="qth_r" placeholder="ex: La Schlucht (88)" value="<?= htmlspecialchars($edit_relais_entry['qth'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="grid-2">
                        <div class="form-group">
                            <label for="latitude_r">Latitude (optionnel, déduite du locator sinon)</label>
                            <input type="text" id="latitude_r" name="latitude_r" placeholder="ex: 48.057245" value="<?= htmlspecialchars($edit_relais_entry['latitude'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="longitude_r">Longitude (optionnel, déduite du locator sinon)</label>
                            <input type="text" id="longitude_r" name="longitude_r" placeholder="ex: 7.018772" value="<?= htmlspecialchars($edit_relais_entry['longitude'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="grid-3">
                        <div class="form-group">
                            <label for="frequence_r">Fréquence</label>
                            <input type="text" id="frequence_r" name="frequence_r" placeholder="ex: 145.6625 MHz (-600 kHz)" value="<?= htmlspecialchars($edit_relais_entry['frequence'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="ctcss_r">CTCSS</label>
                            <input type="text" id="ctcss_r" name="ctcss_r" placeholder="ex: 118.8 Hz" value="<?= htmlspecialchars($edit_relais_entry['ctcss'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="altitude_r">Altitude</label>
                            <input type="text" id="altitude_r" name="altitude_r" placeholder="ex: 1250 m" value="<?= htmlspecialchars($edit_relais_entry['altitude'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="qrz_r">Lien QRZ.com (optionnel)</label>
                        <input type="text" id="qrz_r" name="qrz_r" placeholder="https://www.qrz.com/db/F1ZBV" value="<?= htmlspecialchars($edit_relais_entry['qrz'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label for="webcam_r">Webcam associée (URL d'intégration, optionnel)</label>
                        <input type="text" id="webcam_r" name="webcam_r" placeholder="https://www.skaping.com/la-schlucht/front-de-neige" value="<?= htmlspecialchars($edit_relais_entry['webcam'] ?? '') ?>">
                        <div class="small-note">Si renseignée, cette webcam s'affichera sur la carte publique quand ce relais est sélectionné.</div>
                    </div>

                    <div class="btn-group">
                        <button type="submit"><?= $edit_relais_entry ? '💾 Sauvegarder les modifications' : '➕ Ajouter le relais' ?></button>
                        <?php if ($edit_relais_entry): ?>
                            <a href="<?= tab_url('relais', $current_script) ?>" class="cancel-btn">Annuler</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Relais enregistrés (<?= count($relais_list) ?>)</h2>
                <?php if (empty($relais_list)): ?>
                    <p>Aucun relais défini pour le moment.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Indicatif</th>
                                <th>Locator</th>
                                <th>Fréquence</th>
                                <th>QTH</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($relais_list as $r): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($r['nom']) ?></strong></td>
                                    <td><?= htmlspecialchars($r['indicatif'] ?? '') ?></td>
                                    <td><code><?= htmlspecialchars($r['locator']) ?></code></td>
                                    <td><?= htmlspecialchars($r['frequence'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($r['qth'] ?? '') ?></td>
                                    <td>
                                        <div class="action-links">
                                            <a href="<?= $current_script ?>?tab=relais&edit_relais=<?= $r['id'] ?>" class="edit-btn" title="Modifier">✏️</a>
                                            <a href="<?= $current_script ?>?tab=relais&delete_relais=<?= $r['id'] ?>" class="delete-btn" onclick="return confirm('Supprimer ce relais ? Les reports associés resteront mais ne seront plus rattachés.');" title="Supprimer">❌</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

        <?php elseif ($tab === 'stats'): ?>

            <div class="card">
                <h2>📊 Répartition par catégorie de report</h2>
                <div class="stat-boxes">
                    <?php foreach ($labels_cat as $key => $label): ?>
                        <div class="stat-box">
                            <div class="num"><?= $stats_categories[$key] ?></div>
                            <div class="lbl"><?= $label ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="small-note">Total : <?= count($entries) ?> reports enregistrés.</p>
            </div>

            <div class="card">
                <h2>📡 Reports par relais</h2>
                <?php if (empty($stats_relais_counts)): ?>
                    <p>Aucune donnée.</p>
                <?php else: ?>
                    <table>
                        <thead><tr><th>Relais</th><th>Nombre de reports</th></tr></thead>
                        <tbody>
                        <?php foreach ($stats_relais_counts as $nom => $cnt): ?>
                            <tr><td><?= htmlspecialchars($nom) ?></td><td><?= $cnt ?></td></tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="card">
                <h2>🗺️ Département français estimé (d'après le locator)</h2>
                <p class="small-note">Estimation calculée à partir des coordonnées du centre du locator, comparées au département dont la préfecture est la plus proche. Résultat approximatif, surtout proche des frontières entre départements.</p>
                <?php if (empty($stats_departements)): ?>
                    <p>Aucune donnée.</p>
                <?php else: ?>
                    <table>
                        <thead><tr><th>Département</th><th>Nombre de reports</th></tr></thead>
                        <tbody>
                        <?php foreach ($stats_departements as $dep => $cnt): ?>
                            <tr><td><?= htmlspecialchars($dep) ?></td><td><?= $cnt ?></td></tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="grid-2">
                <div class="card">
                    <h2>🔤 Indicatifs (ordre alphabétique)</h2>
                    <?php if (empty($indicatifs_tries)): ?>
                        <p>Aucune donnée.</p>
                    <?php else: ?>
                        <div class="chip-list">
                            <?php foreach ($indicatifs_tries as $ind): ?>
                                <span class="chip"><?= htmlspecialchars($ind) ?></span>
                            <?php endforeach; ?>
                        </div>
                        <p class="small-note"><?= count($indicatifs_tries) ?> indicatifs distincts.</p>
                    <?php endif; ?>
                </div>

                <div class="card">
                    <h2>🔤 Locators (ordre alphabétique)</h2>
                    <?php if (empty($locators_tries)): ?>
                        <p>Aucune donnée.</p>
                    <?php else: ?>
                        <div class="chip-list">
                            <?php foreach ($locators_tries as $loc => $cnt): ?>
                                <span class="chip"><?= htmlspecialchars($loc) ?> (<?= $cnt ?>)</span>
                            <?php endforeach; ?>
                        </div>
                        <p class="small-note"><?= count($locators_tries) ?> locators distincts.</p>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>

        <p style="text-align: center;"><a href="https://carto-reports.ra88.org" target="_blank"> Voir la carte interactive ➔</a></p>

    <?php endif; ?>
</div>
<script>
    function updateFrequenceFromRelais() {
        const sel = document.getElementById('relais_id');
        const freqField = document.getElementById('frequence');
        if (!sel || !freqField) return;
        const opt = sel.options[sel.selectedIndex];
        const freq = opt ? opt.getAttribute('data-frequence') : '';
        if (freq) freqField.value = freq;
    }
</script>
</body>
</html>
